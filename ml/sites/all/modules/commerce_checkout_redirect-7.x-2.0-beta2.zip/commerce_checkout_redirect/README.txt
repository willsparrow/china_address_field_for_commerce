Commerce Checkout Redirect
--------------------------

This module redirects anonymous users to a page where they can login or create
a new account when they try to checkout.
After the user logs in or registers, he will be redirected to the checkout page.
